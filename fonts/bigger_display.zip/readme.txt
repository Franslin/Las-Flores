Bigger Display is free for commercial and personal use.
It's free, so feel free to use the hashtag #biggerdisplay in your future projects.

Pay what you like:
https://thunderstudio.gumroad.com/l/azvln

Appreciate and follow:
https://www.behance.net/studiothunder
